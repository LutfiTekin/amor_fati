package tekin.luetfi.amorfati.utils

import tekin.luetfi.amorfati.domain.model.TarotCard

object Deck {

    val cards = listOf(
        TarotCard(name = "Ale Of The Ache", code = "ALE_OF_THE_ACHE"),
        TarotCard(name = "Council Of Three", code = "COUNCIL_OF_THREE"),
        TarotCard(name = "Designated Driver", code = "DESIGNATED_DRIVER"),
        TarotCard(name = "Duchess And The White Hound", code = "DUCHESS_AND_THE_WHITE_HOUND"),
        TarotCard(name = "Focus Of Fate", code = "FOCUS_OF_FATE"),
        TarotCard(name = "Gaze Of Exhaustion", code = "GAZE_OF_EXHAUSTION"),
        TarotCard(name = "Gentle Highlander", code = "GENTLE_HIGHLANDER"),
        TarotCard(name = "Gentleman Of The Alps", code = "GENTLEMAN_OF_THE_ALPS"),
        TarotCard(name = "Keeper Of The Bitter Truth", code = "KEEPER_OF_THE_BITTER_TRUTH"),
        TarotCard(name = "Keepers Of The Sky Needle", code = "KEEPERS_OF_THE_SKY_NEEDLE"),
        TarotCard(name = "Lavender Trio", code = "LAVENDER_TRIO"),
        TarotCard(name = "Nine Of Hounds", code = "NINE_OF_HOUNDS"),
        TarotCard(name = "Nomad Of Tracks", code = "NOMAD_OF_TRACKS"),
        TarotCard(name = "Sisters of the Seven Tea", code = "SISTERS_OF_THE_SEVEN_TEA"),
        TarotCard(name = "Round Trip Knight", code = "ROUND_TRIP_KNIGHT"),
        TarotCard(name = "Sentinel Of The Twin Towers", code = "SENTINEL_OF_THE_TWIN_TOWERS"),
        TarotCard(name = "Silent Judge", code = "SILENT_JUDGE"),
        TarotCard(name = "Sister Sinister", code = "SISTER_SINISTER"),
        TarotCard(name = "Snow Mexican", code = "SNOW_MEXICAN"),
        TarotCard(name = "Teacher Of Treachery", code = "TEACHER_OF_TREACHERY"),
        TarotCard(name = "The Alchemist", code = "THE_ALCHEMIST"),
        TarotCard(name = "The Baddies II", code = "THE_BADDIES_II"),
        TarotCard(name = "The Baddies III", code = "THE_BADDIES_III"),
        TarotCard(name = "The Baddies", code = "THE_BADDIES"),
        TarotCard(name = "The Ballad", code = "THE_BALLAD"),
        TarotCard(name = "The Dealer", code = "THE_DEALER"),
        TarotCard(name = "The Distant Liaison", code = "THE_DISTANT_LIAISON"),
        TarotCard(name = "The Endless Pour", code = "THE_ENDLESS_POUR"),
        TarotCard(name = "The Librarian", code = "THE_LIBRARIAN"),
        TarotCard(name = "The Lone Star", code = "THE_LONE_STAR"),
        TarotCard(name = "The Rule Of Threes", code = "THE_RULE_OF_THREES"),
        TarotCard(name = "The Texan And The Thistle", code = "THE_TEXAN_AND_THE_THISTLE")
    )

    val f8Cards = listOf(
        TarotCard(name = "Queen Of Whatever", code = "QUEEN_OF_WHATEVER"),
        TarotCard(name = "Countess Of Chaos", code = "COUNTESS_OF_CHAOS"),
        TarotCard(name = "The Duchess Of Drama", code = "THE_DUCHESS_OF_DRAMA"),
        TarotCard(name = "Maiden Of Mischief", code = "MAIDEN_OF_MISCHIEF"),
        TarotCard(name = "Lady Of Lunacy", code = "LADY_OF_LUNACY"),
        TarotCard(name = "Lady Of The First Flame", code = "LADY_OF_THE_FIRST_FLAME"),
        TarotCard(name = "Mistress Of Mayhem", code = "MISTRESS_OF_MAYHEM"),
        TarotCard(name = "Wench Of Whiskey", code = "WENCH_OF_WHISKEY")
    )

    val locationCards = listOf(
        TarotCard(name = "Tehran", code = "TEHRAN"),
        TarotCard(name = "Hong Kong", code = "HONG_KONG"),
        TarotCard(name = "Baghdad", code = "BAGHDAD"),
        TarotCard(name = "Hanoi", code = "HANOI"),
        TarotCard(name = "Seattle", code = "SEATTLE"),
        TarotCard(name = "New York", code = "NEW_YORK"),
        TarotCard(name = "Athens", code = "ATHENS"),
        TarotCard(name = "Bangkok", code = "BANGKOK"),
        TarotCard(name = "Helsinki", code = "HELSINKI"),
        TarotCard(name = "Bielefeld", code = "BIELEFELD"),
        TarotCard(name = "Berlin", code = "BERLIN"),
        TarotCard(name = "Prague", code = "PRAGUE"),
        TarotCard(name = "Stockholm", code = "STOCKHOLM"),
        TarotCard(name = "Moscow", code = "MOSCOW"),
        TarotCard(name = "Rome", code = "ROME"),
        TarotCard(name = "Brazil", code = "BRAZIL"),
        TarotCard(name = "Barcelona", code = "BARCELONA"),
        TarotCard(name = "Nairobi", code = "NAIROBI"),
        TarotCard(name = "Edinburgh", code = "EDINBURGH"),
        TarotCard(name = "Zermatt", code = "ZERMATT"),
        TarotCard(name = "Johannesburg", code = "JOHANNESBURG"),
        TarotCard(name = "Las Vegas", code = "LAS_VEGAS"),
        TarotCard(name = "Erfurt", code = "ERFURT"),
        TarotCard(name = "Leipzig", code = "LEIPZIG"),
        TarotCard(name = "Antalya", code = "ANTALYA"),
        TarotCard(name = "Amsterdam", code = "AMSTERDAM"),
        TarotCard(name = "Boston", code = "BOSTON"),
        TarotCard(name = "Florence", code = "FLORENCE"),
        TarotCard(name = "Busan", code = "BUSAN"),
        TarotCard(name = "Tokyo", code = "TOKYO"),
        TarotCard(name = "Tbilisi", code = "TBILISI"),
        TarotCard(name = "Bruges", code = "BRUGES"),
        TarotCard(name = "Vienna", code = "VIENNA"),
        TarotCard(name = "San Francisco", code = "SAN_FRANCISCO"),
        TarotCard(name = "Dublin", code = "DUBLIN"),
        TarotCard(name = "Copenhagen", code = "COPENHAGEN"),
        TarotCard(name = "Madrid", code = "MADRID"),
        TarotCard(name = "Dubai", code = "DUBAI"),
        TarotCard(name = "Versailles", code = "VERSAILLES"),
        TarotCard(name = "Istanbul", code = "ISTANBUL"),
        TarotCard(name = "Sheffield", code = "SHEFFIELD"),
        TarotCard(name = "Dresden", code = "DRESDEN"),
        TarotCard(name = "Jerusalem", code = "JERUSALEM"),
        TarotCard(name = "Mumbai", code = "MUMBAI"),
        TarotCard(name = "Venice", code = "VENICE"),
        TarotCard(name = "London", code = "LONDON"),
    )

    val fullDeck = cards + f8Cards + locationCards


}